//
//  PersonalInformationViewController.swift
//  UserSettingsDemo1
//
//  Created by Eddith Figueroa on 10/7/22.
//

import UIKit



class PersonalInformationViewController: UIViewController {
    
    @IBOutlet weak var banner: UIImageView!
    var optionIndex:Int = -1
    
    @IBOutlet weak var thoughts: UITextField!
    @IBOutlet weak var greeting: UILabel!
    @IBOutlet weak var profilePicture: UIImageView!
    
    override func viewWillAppear(_ animated: Bool) {
        if optionIndex != 0{
            thoughts.isHidden = true
            greeting.isHidden = true
            profilePicture.isHidden = true
        }
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
