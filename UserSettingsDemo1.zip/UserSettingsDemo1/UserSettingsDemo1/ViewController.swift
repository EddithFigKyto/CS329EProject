//
//  ViewController.swift
//  UserSettingsDemo1
//
//  Created by Eddith Figueroa on 10/7/22.
//

import UIKit

public let options = ["Personal Information", "Dietary Restrictions",
                      "Community Settings", "Privacy Settings"]

let optionsTextCellIdentifier:String = "optionTVCell"
let personalInformationSegueIdentifier:String = "personalInformationSegue"

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var optionsTableView: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return options.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let row = indexPath.row
        let cell = tableView.dequeueReusableCell(withIdentifier: optionsTextCellIdentifier, for: indexPath)
        
        cell.textLabel?.text = options[row]
        cell.textLabel?.font = UIFont(name:"Avenir Next", size:22)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        optionsTableView.delegate = self
        optionsTableView.dataSource = self
        nameLabel.font = UIFont(name:"Avenir Next", size:22)
    }
    
    
    //when the segue to the calcVC is triggered, operatorIndex is sent to destination
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if optionsTableView.indexPathForSelectedRow?.row == 0{
            if segue.identifier == personalInformationSegueIdentifier,let destination = segue.destination as? PersonalInformationViewController,
               let optionIndex = optionsTableView.indexPathForSelectedRow?.row {
                destination.optionIndex = optionIndex
            }
        }
        
    }
    
    
}
